# Beacon Fork-Choice Simulator (Educational)

A small, dependency-free Python simulator to illustrate a **simplified LMD-GHOST-like**
fork-choice. Useful for teaching and experimentation.

> This is an educational model, not a production fork-choice implementation.

## What it does
- Builds a block tree
- Applies naive weight from validators' latest votes
- Walks the heaviest-child path to pick the head

## Run
```bash
python simulator.py
```

## Extend
- Add validator honesty/fault models
- Add time/slot delays and reorgs
- Compare LMD-GHOST vs. honest-but-lazy rules

## License
MIT
