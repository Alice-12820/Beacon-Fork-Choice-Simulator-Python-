from collections import defaultdict

class Block:
    def __init__(self, id, parent=None):
        self.id = id
        self.parent = parent
        self.children = []
    def __repr__(self):
        return f"Block({self.id})"

class ForkChoice:
    def __init__(self, genesis="G"):
        self.blocks = {genesis: Block(genesis)}
        self.genesis = self.blocks[genesis]
        self.latest_vote = {}  # validator -> block id

    def add_block(self, id, parent):
        if parent not in self.blocks:
            raise ValueError(f"Unknown parent {parent}")
        b = Block(id, parent=parent)
        self.blocks[id] = b
        self.blocks[parent].children.append(id)

    def vote(self, validator, block_id):
        if block_id not in self.blocks:
            raise ValueError(f"Unknown block {block_id}")
        self.latest_vote[validator] = block_id

    def weights(self):
        w = defaultdict(int)
        for v, bid in self.latest_vote.items():
            w[bid] += 1
        return w

    def head(self):
        # Naive LMD-GHOST-like walk: from genesis, repeatedly pick child with most descendant votes
        def subtree_weight(bid, wcache):
            # weight = votes on this block + sum(child subtree weights)
            total = self.weights().get(bid, 0)
            for c in self.blocks[bid].children:
                total += subtree_weight(c, wcache)
            wcache[bid] = total
            return total

        wcache = {}
        subtree_weight(self.genesis.id, wcache)
        cursor = self.genesis.id
        path = [cursor]
        while self.blocks[cursor].children:
            # pick child with highest subtree weight (tie => lexicographic)
            choices = self.blocks[cursor].children
            cursor = sorted(choices, key=lambda x: (-wcache.get(x, 0), x))[0]
            path.append(cursor)
        return cursor, path, wcache

if __name__ == "__main__":
    fc = ForkChoice()

    # Build a small tree
    fc.add_block("A", "G")
    fc.add_block("B", "G")
    fc.add_block("A1", "A")
    fc.add_block("A2", "A")
    fc.add_block("B1", "B")
    fc.add_block("B2", "B")
    fc.add_block("A2a", "A2")

    # Votes
    fc.vote("v1", "A2a")
    fc.vote("v2", "A2")
    fc.vote("v3", "B1")
    fc.vote("v4", "A1")

    head, path, weights = fc.head()
    print("Path:", " -> ".join(path))
    print("Head:", head)
    print("Weights:", dict(weights))
